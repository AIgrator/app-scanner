# src/app_scanner/_macos.py

import logging
import os
import subprocess
from typing import List, Dict

def get_apps() -> List[Dict[str, str]]:
    """
    Scans for applications on macOS using the 'mdfind' command.

    :return: A list of application dictionaries with 'name' and 'path' keys.
    """
    apps = []
    logging.info("Scanning for macOS applications...")
    try:
        # Use mdfind to find all .app bundles, which is the standard for macOS apps.
        command = ["mdfind", "kMDItemContentType == 'com.apple.application-bundle'"]
        result = subprocess.run(
            command, 
            capture_output=True, 
            text=True, 
            check=True,
            encoding='utf-8'
        )
        
        app_paths = result.stdout.strip().splitlines()
        logging.info(f"Found {len(app_paths)} potential applications.")

        for path in app_paths:
            if path.strip():
                try:
                    # The name of the app is typically the filename without the .app extension.
                    app_name = os.path.splitext(os.path.basename(path))[0]
                    apps.append({"name": app_name, "path": path})
                except Exception as e:
                    logging.warning(f"Could not process path '{path}': {e}")
            
    except FileNotFoundError:
        logging.error("'mdfind' command not found. Is this a macOS system?")
    except subprocess.CalledProcessError as e:
        logging.error(f"Error while scanning for macOS apps: {e.stderr}")
    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}")
        
    return apps
