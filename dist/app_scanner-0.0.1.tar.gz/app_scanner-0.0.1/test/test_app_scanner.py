#!/usr/bin/env python3
"""
Тестовый скрипт для проверки работы пакета app-scanner.
"""

import sys
import os

# Добавляем корневую папку проекта в путь, чтобы импортировать пакет
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from app_scanner import get_installed_apps

def main():
    print("Тестирование пакета app-scanner...")
    print(f"Текущая ОС: {sys.platform}")

    try:
        apps = get_installed_apps()
        print(f"Найдено приложений: {len(apps)}")

        if apps:
            print("\nПервые 10 приложений:")
            for i, app in enumerate(apps):
                print(f"{i+1}. {app.get('name', 'Unknown')} - {app.get('appid', app.get('path', 'N/A'))}")
        else:
            print("Приложения не найдены.")

    except Exception as e:
        print(f"Ошибка при тестировании: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()